import Dashboard from "@/components/Dashboard";

export default function PerfilPage() {
  return (
    // Contenedor principal con padding superior para el navbar
    <main className="pt-24">
      <Dashboard />
    </main>
  );
}

