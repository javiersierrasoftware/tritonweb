"use client";

import { useState } from "react";
import Link from "next/link";
import { EVENTS } from "@/data/events";
import EventsFilters from "@/components/events/EventsFilters";
import EventsGrid from "@/components/events/EventsGrid";
import { Event } from "@/types/Event";

export default function EventsPage() {
  const [filters, setFilters] = useState({
    search: "",
    type: "",
    city: "",
  });

  const filteredEvents: Event[] = EVENTS.filter((event) => {
    return (
      (filters.search === "" ||
        event.name.toLowerCase().includes(filters.search.toLowerCase())) &&
      (filters.type === "" || event.type === filters.type) &&
      (filters.city === "" || event.location.includes(filters.city))
    );
  });

  return (
    <main className="max-w-5xl mx-auto px-4 py-14 space-y-8">
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">Calendario de Eventos</h1>
          <p className="text-gray-400 text-sm">
            Carreras, fondos, entrenamientos y eventos especiales de la
            comunidad TRITON.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 text-xs">
          {/* A FUTURO: mostrar solo si el usuario es ADMIN */}
          <Link
            href="/events/create"
            className="inline-flex items-center gap-2 bg-gradient-to-br from-cyan-300 to-orange-300 text-black font-semibold px-4 py-2 rounded-full"
          >
            Crear evento (ADMIN)
          </Link>

          <Link
            href="/events/request"
            className="inline-flex items-center gap-2 border border-cyan-300/60 text-cyan-300 px-4 py-2 rounded-full bg-cyan-300/5"
          >
            Solicitar publicación
          </Link>
        </div>
      </header>

      <EventsFilters onFilterChange={setFilters} />

      <EventsGrid events={filteredEvents} />
    </main>
  );
}