import { NextResponse } from "next/server";
import { Event } from "@/types/Event";
import { v4 as uuidv4 } from "uuid";

/**
 * A FUTURO:
 * - Guardar en BD (Prisma / PostgreSQL)
 * - Validar que el usuario tenga rol ADMIN
 * - Manejar subida de imágenes
 */

// Pequeña validación básica
function validateAdminEvent(body: any) {
  if (!body.name || !body.date || !body.time || !body.location) {
    return "Nombre, fecha, hora y ubicación son obligatorios.";
  }
  if (!body.type) {
    return "Debes seleccionar el tipo de evento/deporte.";
  }
  return null;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const error = validateAdminEvent(body);
    if (error) {
      return NextResponse.json(
        { ok: false, message: error },
        { status: 400 }
      );
    }

    const newEvent: Event = {
      id: uuidv4(),
      name: body.name,
      description: body.description || "",
      date: body.date,
      time: body.time,
      location: body.location,
      type: body.type,
      distance: body.distance || "",
      distances: body.distances || [],
      sport: body.type,
      category: body.category,
      minAge: body.minAge ? Number(body.minAge) : undefined,
      maxAge: body.maxAge ? Number(body.maxAge) : undefined,
      shirtSizes: body.shirtSizes || [],
      registrationPeriods: body.registrationPeriods || [],
      price: body.price || "$0",
      slotsLeft: body.slotsLeft ? Number(body.slotsLeft) : 0,
      image: body.image || "/event-placeholder.jpg",
    };

    // A futuro: guardar en BD.
    console.log("✅ [ADMIN] Nuevo evento creado:", newEvent);

    return NextResponse.json(
      {
        ok: true,
        message: "Evento creado exitosamente (pendiente conectar a BD).",
        event: newEvent,
      },
      { status: 201 }
    );
  } catch (err) {
    console.error("❌ Error al crear evento ADMIN:", err);
    return NextResponse.json(
      { ok: false, message: "Error al crear el evento" },
      { status: 500 }
    );
  }
}