"use client";

export function openRegistration(eventId: string, distance: string) {
  console.log("Iniciando inscripción para:", eventId, distance);

  // Más adelante aquí abriremos un modal o redirigiremos a una página
  alert(`Inscripción para el evento (${eventId}) - Distancia: ${distance}`);
}