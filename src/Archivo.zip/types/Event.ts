// Tipos refinados para categorías y deportes
export type SportType =
  | "Carrera"
  | "Triatlón"
  | "Ciclismo"
  | "Natación"
  | "Entrenamiento"
  | "Otro";

export type AthleteCategory =
  | "Principiante"
  | "Intermedio"
  | "Avanzado"
  | "Elite"
  | "Recreativo";

// Periodos de inscripción por rangos de fechas
export interface RegistrationPeriod {
  label: string;        // Ej: "Inscripción temprana"
  startDate: string;    // YYYY-MM-DD
  endDate: string;      // YYYY-MM-DD
}

// Estructura completa del evento (compatible + extendida)
export interface Event {
  // Campos necesarios para MongoDB
  _id?: string;                  // Mongo los generará automáticamente si está presente
  id: string;                    // ID usado en las URLs (slug), mantiene compatibilidad

  // Datos principales del evento (los que ya usas)
  name: string;
  date: string;
  time: string;
  location: string;
  distance: string;              // Campo existente usado en EventDetail
  price: string;
  type: string;                  // Para compatibilidad: Carrera, Triatlón, etc.
  image: string;
  slotsLeft: number;

  // Nuevos campos avanzados para administración
  description?: string;

  // Varias distancias permitidas
  distances?: string[];

  // Deporte (equivalente a type, pero más estricto)
  sport?: SportType;

  // Categoría del deportista
  category?: AthleteCategory;

  // Rango de edades permitidas
  minAge?: number;
  maxAge?: number;

  // Opciones de tallas de camiseta
  shirtSizes?: string[];        // XS, S, M, L, XL, XXL

  // Periodos de registro por rango de fechas
  registrationPeriods?: RegistrationPeriod[];

  // Datos opcionales para solicitudes externas
  organizerName?: string;
  organizerEmail?: string;
  organizerPhone?: string;
  requestStatus?: "pending" | "approved" | "rejected";

  // Fecha de creación y actualización (estilo MongoDB)
  createdAt?: string;
  updatedAt?: string;
}